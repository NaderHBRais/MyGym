#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verifier.h"
char rech[20];

enum 
{
 ID,
 Jour,
 Mois,
 Annee,
 Heure,
 OBJECTIF,
 TypeEntrainement,
 COLUMNS
};

void
on_lg_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkWidget *input1;
   GtkWidget *input2;
   GtkWidget *output;
   GtkWidget *Login;
   GtkWidget *Admin;
   char Username[20];
   char Password[20];
           input1=lookup_widget(button,"usr");
            strcpy(Username,gtk_entry_get_text(GTK_ENTRY(input1)));
           input2=lookup_widget(button,"pwd");
            strcpy(Password,gtk_entry_get_text(GTK_ENTRY(input2)));
           output=lookup_widget(button, "msg");
     if (verifier(Username,Password)==0)
                 {		
	          Login=lookup_widget(button,"Authentification");
	          Admin=create_EspaceCoach();
	          gtk_widget_show (Admin);
                  gtk_widget_hide(Login);
                 }	
     else
	          gtk_label_set_text(GTK_LABEL (output), "error");

}


void
on_B_modifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
         GtkWidget *MDF;
	 GtkWidget *ID;
         GtkWidget *output;
         GtkWidget *input;
	 GtkWidget *EspaceCoach;
	 GtkWidget *output2;
         char ch[50],id[20],xD[100];
         int hr,ent,je,me,ae,ente,hre;
         char ide[20],obje[1000];
         int ok=0;
                  output=lookup_widget(button,"RZone_Recherche");
		  input=lookup_widget(button,"Zone_Recherche");
                   strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
         FILE* f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","r+");
                if(f!=NULL)
                  {
                   while(fscanf(f,"%s %d %d %d %d %s %d\n",ide,&je,&me,&ae,&hre,obje,&ente)!=EOF)
                        {
                         if(strcmp(id,ide)==0)
                           {
                            ok=1;
                            strcpy(ch,"ID trouvé\n");
                            gtk_label_set_text(GTK_LABEL(output),ch);
                            MDF=create_ModifierSeance();
			    gtk_widget_show (MDF);
			    strcpy(rech,ide);
				strcpy(xD,"");
		
				ID=lookup_widget(button,"IDDSeance");
				gtk_label_set_text(GTK_LABEL(ID),rech);
                           }
			}
		   }
                 if (ok==0)
		   {
	 	    strcpy(ch,"L'ID  non trouvé\n");
		    gtk_label_set_text(GTK_LABEL (output),ch);
		   }
        fclose(f);
}

void
on_B_supprimer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
		GtkWidget *MDF;
		GtkWidget *output;
		GtkWidget *input;
		char ch[50],id[20];
		int hr,ent,je,me,ae,ente,hre;
		char ide[20],obje[1000];
		int ok=0;
			output=lookup_widget(button, "RZone_Recherche");
			input=lookup_widget(button,"Zone_Recherche");
			 strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
		FILE* f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","r+");
		FILE* f1=fopen("/home/ubuntu/Desktop/Coach/Coach/src/mod.txt","w+");
			if(f!=NULL)
			  {
		 	   while(fscanf(f,"%s %d %d %d %d %s %d\n",ide,&je,&me,&ae,&hre,obje,&ente)!=EOF)
				{
				 if(strcmp(id,ide)!=0)
				   {
				    fprintf(f1,"%s %d %d %d %d %s %d\n",ide,je,me,ae,hre,obje,ente);
				   }
				 else ok=1;
				}
			  }
			if (ok==1)
			  {
			   strcpy(ch,"supprimé\n");
			   gtk_label_set_text(GTK_LABEL (output),ch);
			  }
			else  gtk_label_set_text(GTK_LABEL (output),"ID non trouvé");
				fclose(f);
				fclose(f1);
		remove("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt");
        	rename("/home/ubuntu/Desktop/Coach/Coach/src/mod.txt","/home/ubuntu/Desktop/Coach/Coach/src/seance.txt");
}

void
on_B_enregister_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	int ok=1;
	int hr,ent,je,me,ae,ente,hre;
	C coach;
	char sh[100],ide[20],obje[1000],entr;
	GtkWidget *objectif;
	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;
	GtkWidget *heure;
	GtkWidget *entrainement;
	GtkWidget *ID;
	GtkWidget *output;
		output=lookup_widget(button, "Coach_Resultat");
		objectif=lookup_widget(button,"Zone_Objectif");
		 strcpy(coach.obj,gtk_entry_get_text(GTK_ENTRY(objectif)));
		jour=lookup_widget(button, "Jour");
		mois=lookup_widget(button, "Mois");
		annee=lookup_widget(button, "Annee");
		heure=lookup_widget(button, "Heure");
		entrainement=lookup_widget(button, "Type_Entrainement");
		coach.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
		coach.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
		coach.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
	if(strcmp("8h --->10h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
			hr=1;
    else 
	if(strcmp("10h --->12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
			hr=2;
    else
        if(strcmp("14h --->16h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
			hr=3;
    else 
	if(strcmp("16h --->18h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
			hr=4;
    else 
	if(strcmp("18h --->20h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
			hr=5;
    else {ok=0;
	  strcpy(sh,gtk_label_get_text(GTK_LABEL (output)));
	  strcat(sh,"Donnez une format d'heure valide\n");
	  gtk_label_set_text(GTK_LABEL (output),sh);
	 }
		if(strcmp("ABDOS",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=1;
	   else if(strcmp("BOXE",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=2;
	   else if(strcmp("YOGA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=3;
	   else if(strcmp("STEP",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=4;
	   else if(strcmp("LIA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=5;
	   else if(strcmp("TABATA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=6;
	   else if(strcmp("PILATES",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=7;
	   else if(strcmp("GYMBALL",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=8;
	   else if(strcmp("ZOMBA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=9;
	   else if(strcmp("AFRO-DANCE",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
		   ent=10;
	   else {ok=0;
		 strcpy(sh,"Donnez un entrainement valide\n");
		 gtk_label_set_text(GTK_LABEL (output),sh);
		}
			ID=lookup_widget(button,"ID_Seance");
			 strcpy(coach.id,gtk_entry_get_text(GTK_ENTRY(ID)));
	FILE* f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","r+");
		if(f!=NULL)
		  {
		   while(fscanf(f,"%s %d %d %d %d %s %d\n",ide,&je,&me,&ae,&hre,obje,&ente)!=EOF)
			{
			 if(strcmp(coach.id,ide)==0)
			   {
			    ok=0;
			    strcpy(sh,"L'ID deja utilisé\n");
			    gtk_label_set_text(GTK_LABEL (output),sh);
			   }
			    if(hr==hre&&coach.j==je&&coach.m==me&&coach.a==ae)
			      {
				ok=0;
				strcpy(sh,"la seance est deja reservé\n");
				gtk_label_set_text(GTK_LABEL (output),sh);
			      }
			}
		  }
		if(ok==1)
		  {
		   fclose(f);
		   f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","a+");
		   fprintf(f,"%s %d %d %d %d %s %d\n",coach.id,coach.j,coach.m,coach.a,hr,coach.obj,ent);
		   strcpy(sh,"Enregistré\n");
		   gtk_label_set_text(GTK_LABEL (output),sh);
		  }
	fclose(f);
}


void
on_B_M_enregister_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	int ok=1,oks=0;
	int hr,ent,je,me,ae,ente,hre;
	C coach;
	char sh[100],ide[20],obje[1000],entr,xD[50];
	GtkWidget *objectif;
	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;
	GtkWidget *heure;
	GtkWidget *entrainement;
	GtkWidget *ID;
	GtkWidget *output;
		output=lookup_widget(button,"MCoach_Resultat");
		objectif=lookup_widget(button,"MZone_Objectif");
		strcpy(coach.obj,gtk_entry_get_text(GTK_ENTRY(objectif)));
		jour=lookup_widget(button, "MJour");
		mois=lookup_widget(button, "MMois");
		annee=lookup_widget(button, "MAnnee");
		heure=lookup_widget(button, "MHeure");
		entrainement=lookup_widget(button, "MType_Entrainement");
		coach.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
		coach.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
		coach.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
			if(strcmp("8h --->10h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
					hr=1;
		   else if(strcmp("10h --->12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
					hr=2;
		   else if(strcmp("14h --->16h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
					hr=3;
		   else if(strcmp("16h --->18h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
					hr=4;
		   else if(strcmp("18h --->20h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)))==0)
					hr=5;
		   else {ok=0;
			 strcpy(sh,gtk_label_get_text(GTK_LABEL (output)));
			 strcat(sh,"Donnez une format d'heure valide\n");
			 gtk_label_set_text(GTK_LABEL (output),sh);
			}
			if(strcmp("ABDOS",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=1;
		   else if(strcmp("BOXE",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=2;
		   else if(strcmp("YOGA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=3;
		   else if(strcmp("STEP",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=4;
		   else if(strcmp("LIA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=5;
		   else if(strcmp("TABATA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=6;
		   else if(strcmp("PILATES",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=7;
		   else if(strcmp("GYMBALL",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=8;
		   else if(strcmp("ZOMBA",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=9;
		   else if(strcmp("AFRO-DANCE",gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrainement)))==0)
				ent=10;
		   else {ok=0;
			 strcpy(sh,"Donnez un entrainement valide\n");
			 gtk_label_set_text(GTK_LABEL (output),sh);
			}
	strcpy(coach.id,rech);
	FILE* f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","r+");
	FILE* f1=fopen("/home/ubuntu/Desktop/Coach/Coach/src/mod.txt","w+");
			if(f!=NULL)
			  {
			   while(fscanf(f,"%s %d %d %d %d %s %d\n",ide,&je,&me,&ae,&hre,obje,&ente)!=EOF)
				{
				 if(strcmp(coach.id,ide)==0)
				   {
				    fprintf(f1,"%s %d %d %d %d %s %d\n",coach.id,coach.j,coach.m,coach.a,hr,coach.obj,ent);
				    oks=1;
				    strcpy(sh,"L'ID deja utilisé\n");
				    gtk_label_set_text(GTK_LABEL (output),sh);
				   }
				  else
				    fprintf(f1,"%s %d %d %d %d %s %d\n",ide,je,me,ae,hre,obje,ente);
				      if(hr==hre&&coach.j==je&&coach.m==me&&coach.a==ae)
					{
					 ok=0;
					 strcpy(sh,"la seance est deja reservé\n");
					 gtk_label_set_text(GTK_LABEL (output),sh);
					}
				 }
			    }
			  if(ok==1&&oks==1)
			    {
			     strcpy(sh,"Modifié\n");
			     gtk_label_set_text(GTK_LABEL (output),sh);
			    }
	
	fclose(f);
	fclose(f1);
	remove("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt");
	rename("/home/ubuntu/Desktop/Coach/Coach/src/mod.txt","/home/ubuntu/Desktop/Coach/Coach/src/seance.txt");

}

void
on_B_Annuler_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ID,*obj;
ID=lookup_widget(button,"ID_Seance");
obj=lookup_widget(button,"Zone_Objectif");

	if(ID!=NULL||obj!=NULL)
	  {
		gtk_entry_set_text(GTK_LABEL (ID)," ");
		gtk_entry_set_text(GTK_LABEL (obj)," ");
	  }
}


void
on_B_M_Retour_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *EspaceCoach; 
	GtkWidget *ModifierSeance;

		ModifierSeance=lookup_widget(button,"ModifierSeance");
		gtk_widget_destroy(ModifierSeance);
}

void 
afficher_seance(GtkWidget *liste)

{
GtkCellRenderer *renderer;

GtkTreeViewColumn *column;

GtkTreeIter iter;

GtkListStore *store;

        char id[20];
        char ent[1000];
	char j[20];
	char m[20];
	char a[20];
	char hr[20];
        char obj[1000];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if (store==NULL)
{

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("ID",renderer,"text",ID,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",Jour,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",Mois,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",Annee,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("Heure",renderer,"text",Heure,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("OBJECTIF",renderer,"text",OBJECTIF,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("Type Entrainement",renderer,"text",TypeEntrainement,NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  


  store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

  f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","r");

  if(f==NULL)
  {
   	return;
  }
  else 
  
   { f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/seance.txt","a+");
    while(fscanf(f,"%s %s %s %s %s %s %s\n",id,j,m,a,hr,obj,ent)!=EOF)
    {
     

if(strcmp(hr,"1")==0)
strcpy(hr,"8h --->10h");
else if(strcmp(hr,"2")==0)
strcpy(hr,"10h --->12h");
else if(strcmp(hr,"3")==0)
strcpy(hr,"14h --->16h");
else if(strcmp(hr,"4")==0)
strcpy(hr,"16h --->18h");
else if(strcmp(hr,"5")==0)
strcpy(hr,"18h --->20h");
       

if(strcmp(ent,"1")==0)
strcpy(ent,"ABDOS");
else if(strcmp(ent,"2")==0)
strcpy(ent,"BOXE");
else if(strcmp(ent,"3")==0)
strcpy(ent,"YOGA");
else if(strcmp(ent,"4")==0)
strcpy(ent,"STEP");
else if(strcmp(ent,"5")==0)
strcpy(ent,"LIA");
else if(strcmp(ent,"6")==0)
strcpy(ent,"TABATA");
else if(strcmp(ent,"7")==0)
strcpy(ent,"PILATES");
else if(strcmp(ent,"8")==0)
strcpy(ent,"GYMBALL");
else if(strcmp(ent,"9")==0)
strcpy(ent,"ZOMBA");
else if(strcmp(ent,"10")==0)
strcpy(ent,"AFRO-DANCE");






gtk_list_store_append(store,&iter); gtk_list_store_set(store,&iter,ID,id,Jour,j,Mois,m,Annee,a,Heure,hr,OBJECTIF,obj,TypeEntrainement,ent,-1);
    }
    fclose(f);
    gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
    g_object_unref(store);
   }
}
}

void
on_afficher_seances_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *TableauSeance;
  GtkWidget *TableauHistorique;
  GtkWidget *EspaceCoach;

		EspaceCoach=lookup_widget(button,"EspaceCoach");
		gtk_widget_destroy(EspaceCoach);
		TableauHistorique=create_TableauHistorique();
                gtk_widget_show (TableauHistorique);
			  
		TableauSeance=lookup_widget(TableauHistorique,"treeview2");
		afficher_seance(TableauSeance);

}


void
on_RetourTH_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *EspaceCoach;
	GtkWidget *TableauHistorique;

		TableauHistorique=lookup_widget(button,"TableauHistorique");
		gtk_widget_destroy(TableauHistorique);
		EspaceCoach=create_EspaceCoach();
		gtk_widget_show(EspaceCoach);
}

