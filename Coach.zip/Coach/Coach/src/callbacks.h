#include <gtk/gtk.h>

typedef struct{
int ent;
char id[20];
int ti;
int j;
int m;
int a;
char obj[1000];
}C;

void
on_lg_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_B_modifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_B_supprimer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);


void
on_B_enregister_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_B_M_enregister_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_B_Annuler_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_B_M_Retour_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
void 
afficher_seance(GtkWidget *liste) ;


void
on_afficher_seances_clicked            (GtkButton       *button,
                                        gpointer         user_data);


void
on_RetourTH_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
