#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "verifier.h"

int verifier(char login[],char password[])
{
FILE*f;
char user[20]; char pwd[20];
int r=-1;
int role;
if( fopen("/home/ubuntu/Desktop/Coach/Coach/src/users.txt","r") != NULL )
{
f=fopen("/home/ubuntu/Desktop/Coach/Coach/src/users.txt","r");

if (f != NULL)
{
while (fscanf(f, "%s %s %d\n",user, pwd, &role) != EOF )
{
 if ((strcmp(user,login)==0)&&(strcmp(password,pwd)==0))
r=role;
}
fclose(f);
}
}

return r;
}
